from describe import describe

print("isr-mltookit está instalado y funcionando")

print("Función dividir_datos:", describe)
