# isr_mltookit

Paquete de utilidades para Machine Learning: preprocesamiento, evaluación de modelos, y visualización.

## Funcionalidades
-describe

## Instalación

```bash
pip isr_mltookit
