def describe(df):
    print("isr-mltookit está instalado y funcionando")
    return df.describe()

def describe_print(df):
    print(df.describe())
